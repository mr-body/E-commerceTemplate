import { ModeToggle } from '@/components/mode-toggle'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/hooks/auth-context'
import { createFileRoute, useRouter } from '@tanstack/react-router'

export const Route = createFileRoute('/_public/')({
  component: RouteComponent,
})

function RouteComponent() {
  const router = useRouter();
  const { user } = useAuth();

  return (
    <>
      <header className='p-4 flex items-center justify-around'>
        <h1>
          Vite Teste
        </h1>
        <div className='flex items-center justify-center gap-2'>
          {
            user ? (
              <Button variant={'outline'} onClick={() => {
                router.navigate({ to: '/dashboard' })
              }}>
                Dashboard
              </Button>
            ) : (
              <>
                <Button variant={'outline'} onClick={() => {
                  router.navigate({ to: '/login' })
                }}>
                  Login
                </Button>
                <Button variant={'secondary'} onClick={() => {
                  router.navigate({ to: '/signup' })
                }}>
                  Sign up
                </Button>
              </>
            )
          }
          <ModeToggle />
        </div>
      </header>
    </>
  )
}
