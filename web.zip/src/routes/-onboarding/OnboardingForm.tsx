import Step1BasicInfo from '@/components/onboarding/Step1BasicInfo';
import Step2ContactInfo from '@/components/onboarding/Step2ContactInfo';
import Step3ProfessionalInfo from '@/components/onboarding/Step3ProfessionalInfo';
import Step4FinalStep from '@/components/onboarding/Step4FinalStep';
import { useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useMutation } from '@tanstack/react-query';
import { toast } from 'sonner';
import CreateUserInfo from '@/action/requests/createUserInfo';
import { useAuth } from '@/hooks/auth-context';

const steps = [
  Step1BasicInfo,
  Step2ContactInfo,
  Step3ProfessionalInfo,
  Step4FinalStep,
];

export default function OnboardingForm() {
  const methods = useForm({ mode: 'onTouched' });
  const [step, setStep] = useState(0);
  const { user } = useAuth();
  const CurrentStep = steps[step];

  const { mutate } = useMutation({
    mutationFn: async (formData: any) => {
      CreateUserInfo(user.accessToken, formData)
    },
    onSuccess: (data: any) => {
      console.log(JSON.stringify(data, null, 2))
      toast.success('Usuário cadastrado com sucesso');
    },
    onError: () => {
      toast.error('Erro ao enviar dados. Tente novamente.');
    }
  });

  const nextStep = () => setStep((prev) => prev + 1);
  const prevStep = () => setStep((prev) => prev - 1);

  const onSubmit = (data: any) => {
    mutate(data);
  };

  return (
    <FormProvider {...methods}>
      <form onSubmit={methods.handleSubmit(onSubmit)} className="max-w-xl mx-auto space-y-6">
        <CurrentStep />

        <div className="flex justify-between">
          {step > 0 && <button type="button" onClick={prevStep}>← Voltar</button>}

          {step < steps.length - 1 ? (
            <button type="button" onClick={nextStep}>Próximo →</button>
          ) : (
            <button type="submit">Finalizar</button>
          )}
        </div>
      </form>
    </FormProvider>
  );
}
