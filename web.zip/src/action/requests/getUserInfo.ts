export default async function GetUserInfo(token: string) {
    const response = await fetch('http://localhost:3003/user', {
        method: 'GET',
        headers: {
            Authorization: `Bearer ${token}`,
        },
    });

    if (!response.ok) throw new Error('Erro ao buscar usuário');

    return await response.json(); 
}
