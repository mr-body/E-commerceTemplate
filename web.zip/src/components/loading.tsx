export default function PageLoading(){
    return (
        <span>Loading</span>
    )
}